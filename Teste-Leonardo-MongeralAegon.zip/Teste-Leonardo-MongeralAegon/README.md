startr
======

Startr é um tema base para ser usado no desenvolvimento de temas personalizados para empresas e negócios.


Shortcodes
==========

**Sliders**

Para adicionar novos sliders, basta usar o shortcode abaixo:
**[startr_slider id="id-do-slider"]**
O id do slider deve ser único por slider. Os parametros são os mesmos da função get_posts do WordPress, para ver quais são, veja: https://codex.wordpress.org/Template_Tags/get_posts

Para mostrar redes sociais use o seguinte shortcode:
**[startr_social id="home" social="facebook"]**
Coloque um id para facilitar a personalização depois.
Selecione as redes sociais que deseja mostrar (se quiser mostrar todas, não coloque o attributo social).
Opções: facebook, twitter, instagram, pinterest, google-plus, skype.