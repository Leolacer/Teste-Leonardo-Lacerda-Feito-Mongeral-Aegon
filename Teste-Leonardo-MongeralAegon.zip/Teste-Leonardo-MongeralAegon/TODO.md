TO-DOs:

- Corrigir Bugs

- Classe de controle desses elementos da aplicação √

- Base de Ambientes:
-- Dev: usar TGM para requerir degub bar, wordpress reset, etc √
-- Prod: tirar tudo que for de debug. √
-- Comum: coisas que o TGM deve pedir de qualquer jeito. √

- Framework de Modulos, baseado na minha Paradox Framework √
-- Modulo de exemplo para desenvolvimento de novos modulos

- Refatorar:
-- Modulo de custom post types (virar metodo de Paradox)

- Criar:
-- Modulo Slider com seletor de custom post types e etc.
